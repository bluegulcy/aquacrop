library(dplyr)
source('R/Aqua_library.R')

w <- read.csv('input_maize/POWER_SinglePoint_Daily_20140401_20160731_022d64N_120d06E_e2f2785a.csv', skip = 17)
w <- mutate(w, elevation = 369.24)
w = mutate(w, day = apply(w[, c('YEAR', 'DOY')], 1, get_day),
           month = apply(w[, c('YEAR', 'DOY')], 1, get_month),
           year = apply(w[, c('YEAR', 'DOY')], 1, get_year),
           elevation = 369.24,
           mintp = T2M_MIN , mxntp = T2M_MAX, p = PRECTOT, 
           evp = apply(w[, c("T2M_MAX", 'T2M_MIN', 'ALLSKY_SFC_SW_DWN', 'WS2M', 'T2MDEW', 'elevation')],1, get_Eto))
write.table(w[,14:20], file = 'input_maize/Weather_maize.csv', sep =',',
            row.names = FALSE)

