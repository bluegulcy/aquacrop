AOS_Finish <- function(){
# Function to finish AquaCrop-OS simulation and write outputs

## Write outputs ##
    AOS_WriteOutputs()

}

