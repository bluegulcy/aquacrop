#' Soil Parameters to be provided in SoilFile
#' @format An .csv file should be provided with the following fields 
#' \describe{
#' \item{CalcSHP}{Determines if soil hydraulic properties are calculated from textural characteristics of soil layers  Units:0 = No; 1 = Yes   Default value: -}
#' \item{zSoil}{Total thickness of the soil profile  Units:Metres   Default value: -}
#' \item{nComp}{Number of soil compartments  Units:-   Default value: -}
#' \item{nLayer}{Number of soil layers  Units:-   Default value: -}
#' \item{EvapZsurf}{Thickness of the evaporating soil surface layer in direct contact with the atmosphere  Units:Metres   Default value: 0.04}
#' \item{EvapZmin}{Minimum thickness of full soil surface evaporation layer  Units:Metres   Default value: 0.15}
#' \item{EvapZmax}{Maximum thickness of full soil surface evaporation layer  Units:Metres   Default value: 0.3}
#' \item{Kex}{Maximum soil evaporation coefficient  Units:-   Default value: 1.1}
#' \item{fevap}{Shape factor describing the reduction in evaporation with decreasing water 
#' content in the soil surface layer  Units:-   Default value: 4}
#' \item{fWrelExp}{Relative water content of the soil surface layer at which the evaporation
#'  layer depth expands  Units:-   Default value: 0.4}
#' \item{fwcc}{Coefficient expressing the reduction in soil evaporation due to the sheltering effect of withered canopy cover  Units:-   Default value: 0.5}
#' \item{AdjREW}{Determines if the calculated value of readily evaporable water (REW) is overwritten by a user-defined value  Units:0 = No, 1 = Yes   Default value: }
#' \item{REW}{User-defined REW depth (only used if adjusting from the calculated value)  Units:Millimetres   Default value: -}
#' \item{AdjCN}{Determines if the curve number (CN) is adjusted each day based on surface moisture conditions  Units:0 = No, 1 = Yes   Default value: -}
#' \item{CN}{Curve number  Units:-   Default value: -}
#' \item{zCN}{Thickness of the soil surface layer used to calculate moisture content to adjust the curve number  Units:Metres   Default value: 0.3}
#' \item{zGerm}{Thickness of the soil surface layer used to calculate moisture content to determine if germination can occur  Units:Metres   Default value: 0.3}
#' \item{zRes}{Depth of any restrictive soil layer that inhibits root deepening  Units:Metres   Default value: Set to negative value if no restriction is present}
#' \item{fshape_cr}{Shape factor describing the strength of the effect of any shallow groundwater table on soil water content  Units:-   Default value: 16}

#'}

SoilParameters <- function() { 

}